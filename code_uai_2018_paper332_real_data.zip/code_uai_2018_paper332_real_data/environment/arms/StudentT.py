# -*- coding: utf-8 -*-


from random import random
from environment.arms.arm import arm
import numpy as np

class StudentT(arm):
    def __init__(self, p, df, sca):
        self.p = p
        self.expectation = p
        self.df = df
        self.sca = sca
        
    def draw(self):
        return float(self.p + self.sca * np.random.standard_t(self.df))
