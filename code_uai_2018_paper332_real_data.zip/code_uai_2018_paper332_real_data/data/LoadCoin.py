# -*- coding: utf-8 -*-

import numpy as np
from scipy import stats
import os

class LoadCoin:
    def __init__(self):
        self.symbol = ['BTC', 'ETC', 'XRP', 'BCH', 'EOS', 'LTC', 'ADA', 'XLM', 'IOT', 'NEO']
        self.arms_id = {}
        self.truth = {}
        self.truth_stat = {}
        self.payoff_format = 'read' # generate or read
        self.arm_state = 'read' # read or generate
        
        self.dataset = 'coin' # data1, data2 or coin
        self.p = 2 # we set self.p via statistical analysis over the whole real data
        self.B = 0 # value of B will be updated
        self.C = 0 # value of C will be updated
        
        self.Delta = 1
        if self.dataset == 'data1':
            self.nb_arms = 10
        elif self.dataset == 'data2':
            self.nb_arms = 10
        elif self.dataset=='coin':
            self.nb_arms = 10
        self.mode = 'MAB'
        
        for a in range(self.nb_arms):
            self.arms_id.update({a:self.symbol[a]})
        
        path = os.getcwd() + '/data/coin/'
           
        for a in range(self.nb_arms):
            filename = str(self.arms_id[a]) + '.txt'
            self.truth.update({a:[]})
            with open(path+filename,'r') as f:
                for line in f:
                    lstr = line.strip().split('\t')
                    sample = float(lstr[1])
                    self.truth[a].append(sample)
            b = self.truth[a]
            self.truth_stat.update({a:[]})
            [dof,loc,sca] = stats.t.fit(b)
            self.truth_stat[a].append(np.mean(b))
            self.truth_stat[a].append(dof)
            self.truth_stat[a].append(sca)
            
            # update value of B and C        
            if ((self.truth_stat[a][1]/(self.truth_stat[a][1]-2))*self.truth_stat[a][2]**2 + self.truth_stat[a][0]**2)>=self.B:
                self.B = (self.truth_stat[a][1]/(self.truth_stat[a][1]-2))*self.truth_stat[a][2]**2 + self.truth_stat[a][0]**2
                

            if ((self.truth_stat[a][1]/(self.truth_stat[a][1]-2))*self.truth_stat[a][2]**2)>=self.C:
                self.C = (self.truth_stat[a][1]/(self.truth_stat[a][1]-2))*self.truth_stat[a][2]**2
                
        for a in range(self.nb_arms-1):
            for b in range(a+1,self.nb_arms):
                d = abs(np.mean(self.truth[a]) - np.mean(self.truth[b]))
                if d <= self.Delta:
                    self.Delta = d
                    
        