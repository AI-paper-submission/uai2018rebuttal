# -*- coding: utf-8 -*-

import numpy as np

class Result:
    """The Result class for analyzing best arm identification with heavy tails."""
    def __init__(self, nb_epoch, nb_rep):
        self.nb_epoch = nb_epoch
        self.nb_rep = nb_rep
        self.choices = np.zeros([self.nb_epoch, self.nb_rep])
        self.rewards = np.zeros([self.nb_epoch, self.nb_rep])
        self.nb_pulls = np.zeros([self.nb_epoch, self.nb_rep])
        self.probability_error = np.zeros(self.nb_epoch)
        self.probability_stat = np.zeros(2)
        
        self.sample_complexity = np.zeros(self.nb_epoch)
        self.sample_complexity_stat = np.zeros(2)
        
        
    def store(self, epoch, rep, choice, reward, nb_pull):
        self.choices[epoch, rep] = choice
        self.rewards[epoch, rep] = reward
        self.nb_pulls[epoch, rep] = nb_pull
    
    def store_probability_error(self, epoch):
        self.probability_error[epoch] = sum(self.rewards[epoch,:])/float(self.nb_rep)

    def store_probability_stat(self):
        self.probability_stat[0] = np.mean(self.probability_error)
        self.probability_stat[1] = np.sqrt(np.var(self.probability_error))
        
    def store_sample_complexity(self, epoch):
        self.sample_complexity[epoch] = sum(self.nb_pulls[epoch,:])/float(self.nb_rep)
        
    def store_sample_complexity_stat(self):
        self.sample_complexity_stat[0] = np.mean(self.sample_complexity)
        self.sample_complexity_stat[1] = np.sqrt(np.var(self.sample_complexity))    

    