# -*- coding: utf-8 -*-

import numpy as np
import os

class LoadMAB:
    def __init__(self):
        self.arms_id = {}
        self.truth = {}
        self.payoff_format = 'generate' # generate or read
        self.arm_state = 'read' # read or generate
        
        self.dataset = 'data2' # data1, data2 
        self.p = 2
        self.B = 3 # raw moment
        self.C = 3 # central moment
        self.Delta = 1
        self.truth_stat = None
        
        if self.dataset == 'data1':
            self.nb_arms = 10
        elif self.dataset == 'data2':
            self.nb_arms = 10
        self.mode = 'MAB'
        
        
        if self.arm_state == 'generate':
            if self.dataset == 'data2':
                for i in range(self.nb_arms):
                    mean = np.random.uniform(0,1)
                    var = np.random.uniform(1,2)
                    self.truth[i] = [mean, var]
                    
            if self.dataset == 'data3':
                for i in range(self.nb_arms):
                    y = i+1
                    if y==1:
                        mean = 1.0
                        var = 1.0
                    else:
                        mean = 1-1.0/(2*y**2)
                        var = 2-1.0/(2*y)
                    self.truth[i] = [mean,var]
            self.nb_arms = len(self.truth)
            
        path = os.getcwd() + '/data/'    
        filename = self.dataset+'arm'+str(self.nb_arms) + '.txt'
        
        if self.arm_state == 'read':
            self.nb_arms = 0
            with open(path+filename, 'r') as f:
                for line in f:
                    lstr = line.strip().split()
                    mean = float(lstr[0])
                    var = float(lstr[1])
                    self.truth[self.nb_arms] = [mean, var]
                    self.nb_arms += 1
        else:
            with open(path+filename, 'w') as f:
                for i in range(self.nb_arms):
                    mean = self.truth[i][0]
                    var = self.truth[i][1]
                    f.write(''+str(mean)+' '+str(var))
                    f.write('\n')      
                    
        for a in range(self.nb_arms):
            for b in range(self.nb_arms):
                if a==b:
                    continue
                else:
                    d = abs(self.truth[a][0] - self.truth[b][0])
                    if d <= self.Delta:
                        self.Delta = d
        if self.Delta == 0:
            self.Delta = 0.1