# -*- coding: utf-8 -*-

import datetime # to show the date and time
import timeit # to calculate the time consumption
import os  # to save files

import random as rand
import numpy as np
from matplotlib.pyplot import *

#from data.Load import Load
from data.LoadMAB import LoadMAB
from environment.MAB import MAB
from evaluation.Evaluation import Evaluation

from policy.MABEA import MABEA
from policy.MABTEA import MABTEA

from policy.posterior.Beta import Beta
from policy.posterior.GaussianPosterior import GaussianPosterior

from plotSetting.FigureSetting import FigureSetting

# graphic setting
graphic = 'yes'

# running setting
nb_epoch = 50

nb_rep = 10 # 10  

hs = [400,500,600,700,800,900,1000,1100] # horizons for fixed T [400,500,600,700,800,900,1000,1100]
ds = [0.005,0.010,0.015,0.020,0.025,0.030,0.035,0.040] # confidences for fixed delta [0.005,0.010,0.015,0.020,0.025,0.030,0.035,0.040]

setting = 'b' # 'c' for confidence or 'b' for budget

##############################

if graphic == 'yes':
    bar_width = 0.1
    opacity = 0.9
    f = FigureSetting(graphic)
    f.color()
    cols = f.colors
    f.marker()
    mas = f.markers
    figure(1)


if setting == 'b':
    ps = hs
else:
    ps = ds


data = LoadMAB()
print('#arms: '+str(data.nb_arms))
print('#repetitions: '+str(nb_rep))  
print('#epochs: '+str(nb_epoch))
print('setting: '+str(setting))
print("B: "+str(data.B))
print("C: "+str(data.C))

plot_mean_probability_error = np.zeros([len(ps), 2])
plot_std_probability_error = np.zeros([len(ps), 2])
plot_mean_sample_complexity = np.zeros([len(ps), 2])
plot_std_sample_complexity = np.zeros([len(ps), 2])
time_consumption = []

for s in ps:
    parameter = s

    env = MAB(data,setting,nb_rep)
    policies = [MABEA(data, setting, parameter),MABTEA(data, setting, parameter)]
    time_con = []    
    k=0
    
    for policy in policies:
        print("===============================")
        print(policy)
        print(datetime.datetime.now())
        time_begin = timeit.default_timer()
        game = Evaluation(env, policy, nb_epoch, nb_rep, setting, parameter)
        if setting == 'b':
            result = game.play_SR()
        else:
            result = game.play_SE()
        
        time_end = timeit.default_timer()
        time_con.append(time_end-time_begin)
        
        print("select arm: ", result.choices)
        print("probability of error: ", result.probability_error)
        
        print("-------------------------------")
        print(policy)
        print('setting: '+str(setting))
        print("parameter: "+str(parameter))
        print("time_consumption: ", time_end-time_begin)
        print("stat [probability of error, variance of probability]: ")
        print(result.probability_stat)
        print("stat [sample complexity, variance of sample complexity]: ")
        print(result.sample_complexity_stat)
        print("===============================")
        print("\n")
        
        plot_mean_probability_error[ps.index(s),k] = result.probability_stat[0]
        plot_std_probability_error[ps.index(s),k] = result.probability_stat[1]
        plot_mean_sample_complexity[ps.index(s),k] = result.sample_complexity_stat[0]
        plot_std_sample_complexity[ps.index(s),k] = result.sample_complexity_stat[1]
            
        k = k+1
    time_consumption.append(time_con)
time_con_stat = np.zeros([len(policies),2])

for p in range(len(policies)):
    time_con = 0
    var_con = 0
    for t in range(len(ps)):
        time_con += time_consumption[t][p]
        var_con += time_consumption[t][p]**2
    time_con_stat[p][0] = time_con/len(ps)
    time_con_stat[p][1] = var_con/len(ps)-time_con_stat[p][0]**2
    
time_id = str(datetime.datetime.now())
time_id = time_id.replace(':','.')
time_id = time_id.replace(' ','-')
os.makedirs(os.path.dirname('results/data/'+str(time_id)+'/'), exist_ok=True)
os.makedirs(os.path.dirname('results/figure/'), exist_ok=True)

k = 0
for obj in policies:
    # save data
    i = 2*k+1
    if obj.name.find('TEA') != -1:
        filename = str(obj.name[:2]) + '_TEA'
    else:
        filename = str(obj.name[:2]) + '_EA'
    with open('results/data/'+str(time_id)+'/stat_'+filename+'.txt','w') as f:
        f.writelines(str(time_id)+'\n')
        f.writelines(str(obj.name)+'\n')
        f.writelines('setting: '+str(setting)+'\n')
        f.writelines('parameters: '+str(ps)+' ')
    
    with open('results/data/'+str(time_id)+'/results_'+filename+'.txt','w') as f:
        f.writelines(str(time_id)+'\n')
        f.writelines(str(obj.name)+'\n')
        f.writelines('\n')
        f.writelines("++++++++++ time consumption ++++++++++"+'\n')
        f.writelines("mean (second)"+"\t"+"standard deviation" + '\n')
        f.writelines(str(time_con_stat[k][0])+"\t"+str(time_con_stat[k][1]))
        f.writelines('\n')
        f.writelines("time consumption details (second): "+'\n')
        f.writelines(["%s " % i[k]  for i in time_consumption])
        f.writelines('\n')
        f.writelines("========== end of time consumption =========="+'\n')
        
        f.writelines('\n')
        f.writelines("++++++++++ probability of error ++++++++++"+'\n')
        f.writelines("mean: " + '\n')
        f.writelines(["%s " % item  for item in plot_mean_probability_error[:,k]])
        f.writelines('\n')
        f.writelines("standard deviation: "+'\n')
        f.writelines(["%s " % item  for item in plot_std_probability_error[:,k]])
        f.writelines('\n')
        f.writelines("========== end of probability of error =========="+'\n')
        
        f.writelines('\n')
        f.writelines("++++++++++ sample complexity ++++++++++"+'\n')
        f.writelines("mean: " + '\n')
        f.writelines(["%s " % item  for item in plot_mean_sample_complexity[:,k]])
        f.writelines('\n')
        f.writelines("standard deviation: "+'\n')
        f.writelines(["%s " % item  for item in plot_std_sample_complexity[:,k]])
        f.writelines('\n')
        f.writelines("========== end of sample complexity =========="+'\n')
        
    # plot figure
    if graphic == 'yes':
        matplotlib.rcParams.update({'font.size': 14})
        ax = gca()
        #plt.bar(ps, plot_mean[:,k], bar_width, alpha=opacity,color=cols[k], marker = mas[k],yerr=plot_std[:,k], error_kw=dict(ecolor='grey', lw=2, capsize=5, capthick=2))
        if setting == 'b':
            plot(ps, plot_mean_probability_error[:,k], color = cols[k], marker = mas[k])
        else:
            semilogy(ps, plot_mean_sample_complexity[:,k], color = cols[k], marker = mas[k])
#        ax.errorbar(ps, plot_mean[:,k], yerr=plot_std[:,k], fmt='none',ecolor=cols[k], capsize=3, label='_nolegend_')
#        #ax.set_xscale('log')
        if setting == 'b':
            ylabel('Probability of Error')
            xlabel('Fixed Budget $T$')
        else:
            ylabel('Sample Complexity')
            xlabel('Fixed Confidence $\delta$')
    k += 1
            
# save figure
if graphic == 'yes':
    matplotlib.rcParams.update({'legend.labelspacing':0.25})
    matplotlib.rcParams.update({'font.size': 14})
    legend_name = [obj.name for obj in policies]
    legend(legend_name, loc='best')
    savefig('results/figure/'+str(time_id)+'.png',bbox_inches='tight', dpi = 300)
    show()