# -*- coding: utf-8 -*-

import random
import numpy as np

from evaluation.Result import *

class Evaluation:
  
    def __init__(self, env, pol, nb_epoch, nb_rep, setting, parameter):
        self.env = env
        self.best = 0 # initialization
        self.policy = pol
        self.nb_epoch = nb_epoch
        self.nb_repetitions = nb_rep
        self.nb_arms = env.nb_arms
        self.nb_pulls = np.zeros([self.nb_epoch, self.nb_repetitions])
        
        self.setting = setting
        if self.setting == 'b':
            self.horizon = parameter
        else:
            self.delta = parameter
            
        self.H1 = 1 
        self.H3 = 1
        
    def play_SE(self):
        if self.best_arm(): # determine the best arm in hindsight
            print("best arm: ", self.best)
            pass
        else:
            print("Error: no unique best arm")
            print(Error)
        result = Result(self.nb_epoch, self.nb_repetitions)

        for epoch in range(self.nb_epoch):
            for rep in range(self.nb_repetitions):
                t = 0
                nb_pull = 0
                decision_set = self.policy.start_game(self.env)
                
                while (len(decision_set.keys())>1):
                    for arm in decision_set:
                        reward = self.env.generate_payoff(arm)
                        self.policy.get_reward(self.env, arm, None, reward)
                        
                    nb_pull += len(decision_set)
                    t += 1
                    index = dict()
                    for arm in decision_set:
                        index[arm] = self.policy.arm_est[arm][0]
                        
                    max_index = max(index.values())
                    baseline_arm = random.choice([arm for arm in index.keys() if index[arm] == max_index])
                    decision_set_new = decision_set.copy() 
                    baseline_arm_est = self.policy.arm_est[baseline_arm][0]
                    c_t = self.policy.set_confidence_bound(baseline_arm)
                    
                    for arm in decision_set:
                        arm_est = self.policy.arm_est[arm][0]
                        if (baseline_arm_est - arm_est > 2*c_t) and len(decision_set_new) > 1:
                            del decision_set_new[arm]
                    decision_set = decision_set_new.copy() 
                    
                    if len(decision_set) == 1:
                        for arm in decision_set:
                            best_choice = arm
                            
                if best_choice in self.best:
                    reward = 0.0
                else:
                    reward = 1.0
                self.nb_pulls[epoch, rep] = nb_pull
                result.store(epoch, rep, best_choice, reward, nb_pull)
                
                
            result.store_sample_complexity(epoch)
            result.store_probability_error(epoch)
           
        result.store_probability_stat()  
        result.store_sample_complexity_stat()
        return result            

    def play_SR(self):
        if self.best_arm(): # determine the best arm in hindsight
            print("best arm: ", self.best)
            pass
        else:
            print("Error: no unique best arm")
            print(Error)
        result = Result(self.nb_epoch, self.nb_repetitions)
        
        best_set = dict()
        for arm in range(self.nb_arms):
            best_set[arm] = 0
        for epoch in range(self.nb_epoch):
            for rep in range(self.nb_repetitions):
                nb_pull = 0
                phrases = self.policy.start_game(self.env)
                self.policy.restart_decision_set()
                
                for k in range(1,self.nb_arms):
                    n = int(phrases[k]) - int(phrases[k-1]) 
                    decision_set = self.policy.get_decision_set()
                    
                    for arm in decision_set:
                        for t in range(n):
                            reward = self.env.generate_payoff(arm)
                            self.policy.get_reward(self.env, arm, None, reward)
                            nb_pull += 1
                    index = dict()
                    for arm in decision_set:
                        index[arm] = self.policy.compute_index(arm)
                    max_index = min(index.values())
                    best_arms = [arm for arm in index.keys() if index[arm] == max_index]
                    action = random.choice(best_arms)
                    self.policy.update_decision_set(action)
                
                decision_set = self.policy.get_decision_set() 
                if len(decision_set) == 1:
                    best_choice = decision_set[0]
                else:
                    best_choice = None
                    
                if best_choice in self.best:
                    reward = 0.0
                else:
                    reward = 1.0
                self.nb_pulls[epoch, rep] = nb_pull
                result.store(epoch, rep, best_choice, reward, nb_pull)
                
                #print("trancated number: ", self.policy.number_trancated())    
            result.store_sample_complexity(epoch)
            result.store_probability_error(epoch)
           
        result.store_probability_stat()  
        result.store_sample_complexity_stat() 
        return result
    

    def mean_number_pulls(self):
        mean_pulls = np.zeros(self.nb_epoch)
        var_pulls = np.zeros(self.nb_epoch)
        for i in range(self.nb_epoch):
            mean_pulls[i] = np.mean(self.nb_pulls[i,:])
            var_pulls[i] = np.var(self.nb_pulls[i,:])
        return [np.mean(mean_pulls), np.var(mean_pulls)]
   
    def best_arm(self):
        mv = dict()
        for i in self.env.truth:
            mv[i] = self.env.truth[i][0]
        min_index = max (mv.values())
        best_arm = [arm for arm in mv.keys() if mv[arm] == min_index]
        if len(best_arm) < 1:
            return False
        else:
            self.best = best_arm
            self.H_1 = 0.0
            self.H_3 = 0.0
            for i in mv:
                if i not in self.best:
                    self.H1 += 1.0/(mv[i] - mv[self.best[0]])**2
                    self.H3 += 1.0/(mv[i] - mv[self.best[0]])
            return True        