# -*- coding: utf-8 -*-
'''Arm with Bernoulli distribution.'''


from random import random
from environment.arms.arm import arm

class Bernoulli(arm):
    def __init__(self, p):
        self.p = p
        self.expectation = p
        self.variance = p*(1-p)
        
    def draw(self):
        return float(random()<self.p)
