# -*- coding: utf-8 -*-

from random import choice
import numpy as np

class IndexPolicy:
    def __init__(self, data):
        self.arms_id = data.arms_id
        self.nb_arms = data.nb_arms
        self.p = data.p
        self.B = data.B
        self.C = data.C
        self.Delta = data.Delta
        
    def choice_index(self, env, number):
        """In an index policy, choose at random an arm with maximal index."""
        index = dict()
        
        if env.mode == 'yahoo':
            arms = []
            arms_index = env.feedbacks_id[number][3]
            for a in arms_index:
                arms.append(self.arms_id[a])
        else:
            arms = list[self.arms_id.keys()]
            
        for arm in arms:
            #print("arm", arm)
            if self.context == 'None':
                index[arm] = self.compute_index(env, arm, None)
            else:
                index[arm] = self.compute_index(env, arm, self.context[arm])
            #print("index=====", index[arm])
        max_index = max (index.values())
        best_arms = [arm for arm in index.keys() if index[arm] == max_index]
        return choice(best_arms)