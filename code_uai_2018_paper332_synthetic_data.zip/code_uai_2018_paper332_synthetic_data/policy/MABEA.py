# -*- coding: utf-8 -*-

import numpy as np
from policy.IndexPolicy import IndexPolicy

class MABEA(IndexPolicy):
    """Empirical Average
      Reference1: [Even-Dar, Mannor, and Mansour - COLT, 2002].
    """
    def __init__(self, data, setting, parameter):
        IndexPolicy.__init__(self, data)
        
        self.arm_est = {}
        self.setting = setting
        if self.setting == 'b':
            self.horizon = parameter 
            self.name = 'SR-$T$(EA)'
        else:
            self.delta = parameter
            self.name = 'SE-$\delta$(EA)'
            self.Cp = (8*(self.p-1)*max(1,2**(self.p-3)))**(self.p)
            
        
    def start_game(self, env):
        self.arm_est = {}
        for arm in range(self.nb_arms):
            self.arm_est.update({arm:[0,0]})
        
        self.decision_set = [k for k in range(self.nb_arms)]
        if self.setting == 'b':
            self.logK = 1.0/2+sum([1.0/k for k in range(2,self.nb_arms+1)])
            self.phrases = np.zeros(self.nb_arms)
            for k in range(1,self.nb_arms):
                self.phrases[k] = (self.horizon-self.nb_arms)/((self.nb_arms+1-k)*(self.logK))
            self.phrases = np.ceil(self.phrases)
            return self.phrases
        else:
            return self.arm_est
    
    def get_time_index(self, arm_id):
        return len(self.arm_est[arm_id])
    
    def restart_decision_set(self):
        self.decision_set = [k for k in range(self.nb_arms)]
    
    def get_decision_set(self):
        return self.decision_set
    
    def set_confidence_bound(self, arm_id):
        count = self.arm_est[arm_id][1]
        if self.p <= 2:
            c_t = (2*self.C*self.nb_arms/(self.delta*count**(self.p-1)))**(1/self.p)
        else:
            c_t = (self.C*self.Cp*self.nb_arms/(self.delta*count**(self.p/2)))**(1/self.p)
        
        return c_t
    
    def get_reward(self, env, arm_id, arm, reward):
        count = self.arm_est[arm_id][1]
        self.arm_est[arm_id][1] += 1
        self.arm_est[arm_id][0] = (count*self.arm_est[arm_id][0] + reward)/(count + 1)

    def number_trancated(self):
        return 0  
        
    def update_decision_set(self, action):
        self.decision_set.remove(action)
    
    def compute_index(self, arm_id):
        return self.arm_est[arm_id][0]